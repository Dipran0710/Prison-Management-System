# Prison Management System
This system is made to keep the records about the prisoners and about the guards. Jailor can log in as a user and can add the details of prisoners like name, age, address, crime and punishment.
