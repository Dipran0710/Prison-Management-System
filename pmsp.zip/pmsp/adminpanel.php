

<head>
  <title>ADMIN</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align="center" border="0" bgcolor="grey" width="50%" height='100%' cellpadding="8" cellspacing="0" height="500">
          
		  <tr>
            <td colspan='7' height="100%" width='200%' height='2'><img src='2.gif'></td>
          </tr>
		  <tr>
            <td colspan="7" bgcolor="grey" height="1" align="left">
		      <h1><font size="5">
	          
               <a href="registration.php">RegisterPrisoner</a>| | | 
		       <a href="transfer.php">PrisonerTransfer </a> | | |
			   <a href="court.php">Court</a>| | |
			   <a href="search-form.php">Search</a> | | |
			   <a href="sp.php">OfficerDetails</a>| | |
		        <a href="officertransfer.php">OfficerTransfer</a> 
		        </font></h1>
            </td>
			 </td>
		 
            <td height='1' colspan='3' align='right' bgcolor="grey"></td>
			
          </tr>
		 
          <tr>
		 
          
           
<p align='center'>
 

<h3 align='center'></h3>
<br/>
<td height="40" width="50%" bgcolor="sky_blue">
<U><h1 align='center'>WELCOME ADMINISTRATOR</h1></U>
<I><B><p align='cellspacing'><font size="5"><font  face='Arial, Helvetica, sans-serif'>:-The system enables an Administrator to provide services to users and here the administrator can add and upload information, delete, view the record added.</font></font></p></B></I></td>

		<br>
			</td>
            <td width='10%'  bgcolor='grey'  valign='center'>
			
	
<table border='10' align='center' >
<tr>
<td width="100" height="1" bgcolor="sky_blue">
<h1 align="center"> Admin Management  </h1></td>




<ul>
<tr>
            <td colspan="7" bgcolor="sky_blue" height="1" align="center">
		      <h1><font size="5">
			 <U> <a href='viewprisoners.php'><b>Prisoner  Information</a> <br><br></U>
			 <U>  <a href='viewtransfer.php'><b>View Prisoner Transfer </a><br><br></U>
			   <U><a href='viewcase.php'><b>Case Information</a> <br><br></U>
	          <U> <a href='viewofficer.php'><b>View Officer Transfer</a><br><br></U>
              <U> <a href='bkp.php'><b>Prisoner Backup </a> <br><br>
	<br></U>
	
   <U>   <a href='index.php'>LOGOUT</a></U>

				
		        </font></h1>
            </td>
			 </td>
		 
            
          </tr>


</ul>
</td>
</tr>
</table>


			
			</td>
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='grey' height='1'>
				<font size="5">	<I><B><strong>
                @SmartKnower_Deep</strong></td></B></I></font>
          </tr>
	</table>
</body>
</head>
</html>