<html>
<head>
<title>Court form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" width='100%' height='100%' bgcolor="grey" align="center" >
<tr bgcolor="grey">
<td align="center">
<U><h1> COURT </h1></U>
<font size="5">

</font>
</td>
</tr>
<tr>
<td>
<form action="processcourt.php" method="post">
<table bgcolor="grey" height="500" border="0" align="center" width="50%">
<td width="34%" bgcolor="grey"><b>National ID:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Nationalid" /></td>
</tr>
<tr>
<td bgcolor="grey"><b>File Number:</b></td>
<td bgcolor="grey"><input type="text" name="Filenum" /></td>
</tr>
<tr>
<td bgcolor="grey"><b>Date Of Trial:</b></td>
<td bgcolor="grey"><input type="text" placeholder="YYYY-MM-DD" name="dot" /></td>
</tr>
<tr><td bgcolor="grey"><b>Sentence:</b></td>
        <td> <select name="sentence">
		 <option>2 Weeks</option>
        <option>1 to 3 Months</option>
		<option>1year</option>
		<option>5 to 10 Years</option>
        <option>15 Years</option>
		<option>Life Sentence</option></td></tr>
		
<tr><td bgcolor="grey"><b>Court Location:</b></td>
        <td> <select name="location">
		 <option>Mysuru Court</option>
        <option>Bengaluru Court</option>
		<option>Hassan Court</option>
		<option>Madikeri Court</option>
        <option>Mandya Court</option>
		<option>Managaluru Court</option>	</td></tr>

      <td height="26" bgcolor="grey" align="center"><input type="submit" value="SAVE" /></td>
 </tr>
</table>
</form>
</td>
</tr>
<tr bgcolor="sky_blue">
<td align="center" height='4%'>
<font size="5">
<a href="adminpanel.php">BACK</a> 
</font>
</td>
</tr>
 <tr>
            <td colspan='3' align='center' bgcolor='grey' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>