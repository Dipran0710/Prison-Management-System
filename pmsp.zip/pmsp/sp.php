<html>
<head>
  <U><title> OFFICER  </title></U>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='BLACK' width='100%' height='100%' cellpadding='9' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='grey' valign='top'>



<?php 

  //connect to database
  $conn=mysqli_connect("localhost", "root","") or die(mysqli_error());
  mysqli_select_db($conn,"prison") or die("Cannot connect to database");

  //run the store proc
  $result = mysqli_query($conn,"CALL example") or die("Query fail: " . mysqli_error($conn));
  echo"<table align='top' width='100%' border='0' cellpadding='3' cellspacing='2' bgcolor='grey'>
<caption><U><h1>OFFICER INFORMATION</h1></U></caption>
<tr bgcolor='sky_blue'>
<th width='5%'>Officer Id</th>
<th width='5%'>Station Id</th>
<th width='12%'>Station Name</th>
<th width='10%'>Name</th>
<th width='10%'>Address</th>
<th width='10%'>City</th>
<th width='15%'>Email</th>
<th width='5%'>Mobile</th>



</tr>";

  //loop the result set
  while ($row = mysqli_fetch_array($result)){   
    echo "<tr bgcolor='lime'>";
echo  "<td width='3%'>".$row ['Officer_Id']."</td>";
echo  "<td width='3%'>".$row ['Station_Id']."</td>";
echo  "<td width='7%'>".$row ['Station_Name']."</td>";
echo  "<td width='8'>".$row ['name']."</td>";
echo  "<td width='10%'>".$row ['Address']. "</td>";
echo  "<td width='10%'>".$row ['City']."</td>";
echo  "<td width='10%'>" .$row ['Email']."</td>";
echo  "<td width='8%'>".$row ['Mobile']."</td>";

//echo  "<td width='8'>".$row ['password']."</td>";
echo "</tr>";		
  }
echo"</table>";
?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center" height='6%' bgcolor='sky_blue'><B><a href="adminpanel.php" target="_parent" >BACK <b> | </b></a></B>
			<B><a href="addoff.php" target="_parent">ADD<b> |</b></a></B>
			<B><a href="deloff.php" target="_parent">DELETE<b></b></a></B>
			
		
          </tr>
           <tr>
            <td colspan='3' align='center' bgcolor='grey' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
	</table>
</body>
</head>
</html>
