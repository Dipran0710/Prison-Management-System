<html>
<head>
<title> Transfer Form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table width="100%" height="100%" border="0" align="center" bgcolor="grey">
<tr bgcolor="sky_blue">
<td align="center" width="0" height='8%'>
<font size="5">
<U><I><h3>PRISONER TRANSFER</h3></I></U>
</font>
</td>
</tr>
<td height="5" bgcolor="grey"><tr>
<td>
<form action="processtransfer.php" method="post">
<table bgcolor="grey" height="500" border="0" align="center" width="50%">
<td width="34%" bgcolor="grey"><b>National ID:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Nid" /></td>
</tr>
<td width="34%" bgcolor="grey"><b>File Number:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Filenum" /></td>
</tr>

<tr><td bgcolor="grey"><b>From Prison:</b></td>
        <td> <select name="From">
        <option>MYSURU</option>
		<option>BENGALURU</option>
		<option>HASSAN</option>
		<option>MADIKERI</option>
		<option>MANDYA</option>
		<option>MANGALURU</option></td></tr>
	<tr><td bgcolor="grey"><b>To Prison:</b></td>
        <td> <select name="To">
		<option>MYSURU</option>
		<option>BENGALURU</option>
		<option>HASSAN</option>
		<option>MADIKERI</option>
		<option>MANDYA</option>
		<option>MANGALURU</option></td></tr>
<tr>
<td bgcolor="grey"><b>Date of Transfer:</b></td>
<td bgcolor="grey"><input type="text" placeholder="YYYY-MM-DD" name="dot" /></td>

</tr>
  <td height="26" bgcolor="grey" align="center"><input type="submit" value="Add" /></td>
 </tr>
</table>
</form>
</td>
<td bgcolor="grey"></tr>
<tr>
<td height="33"  align="center" bgcolor="sky_blue">
<font size="5">
<a href="adminpanel.php">BACK</a> 
</font>
</td>
</tr>
 <tr>
            <td colspan='3' align='center' bgcolor='grey' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>