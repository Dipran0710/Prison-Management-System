<html>
<head>
<title>registration  form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" bgcolor="grey" align="center" width="100%" height='100%'>
<tr bgcolor="grey">
<td align="center">
<font size="6">
<U><h2>Add Officer</h2></U>
</font>
</td>
</tr>
<tr>
<td>

<form action="offreg.php" method="post">
<table bgcolor="grey" height="450" border="0" align="center" width="50%">
<tr>
<tr>		
<td width="34%" bgcolor="grey"><b>Officer Id:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Officer_Id"  />

</tr>
<tr>		
<td width="34%" bgcolor="grey"><b>Station Id:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Station_Id"  />


</tr>
<tr>
<td bgcolor="grey"><b>Station Name:</b></td>
<td bgcolor="grey"><input type="text" name="Station_Name"  /></td>
</tr>

<tr>
<td bgcolor="grey"><b>Address:</b></td>
<td bgcolor="grey"><input type="text" name="Address" /></td>
</tr>

<tr>
<td bgcolor="grey"><b>City:</b></td>
<td bgcolor="grey"><input type="text" name="City" /></td>
</tr>


<tr>
<td bgcolor="grey"><b>Email:</b></td>
<td bgcolor="grey"><input type="text" name="Email" /></td>
</tr>

<tr>
<td bgcolor="grey"><b>Mobile:</b></td>
<td bgcolor="grey"><input type="text" name="Mobile" /></td>
</tr>

<tr>
<td bgcolor="grey"><b>Name:</b></td>
<td bgcolor="grey"><input type="text" name="name" /></td>
</tr>

<tr>
<td bgcolor="grey"><b>Password:</b></td>
<td bgcolor="grey"><input type="text" name="password"  /></td>
</tr>		


   <td height="26" bgcolor="grey" align="center"><input type="submit" value="SAVE" /></td>
 </tr>
</table>
</form>
</td>
</tr>
<tr bgcolor="sky_blue">
<td align="center" height='4%'>
<font size="5">
<a href="sp.php">BACK</a> 
</font>
</td>
</tr>
 <tr>
            <td colspan='3' align='center' bgcolor='grey' height='1'>
				<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>