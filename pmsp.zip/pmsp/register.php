<html>
<head>
   
	<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align="center" border="0" bgcolor="black" width="100%" cellpadding="9" cellspacing="0" height="100%">
          <tr>
            <td colspan="3" height="2"><img src="2.gif" width="100%"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="black" height="1" align="center">
		<font size="4">
         <a href="index.php">HOME</a>
      
          </font>
            </td>
          </tr>
          <tr>
            <td width="25%" bgcolor="white" >&nbsp;&nbsp;<img src="6.jpg" width="400" height="200"  alt=""/></td>
            <td width="50%" align="center" bgcolor="#FFFFFF">
<div class="ex">

<form action="newuser.php" method="POST">
<table width="408" height="142" border="0" bgcolor="white">
	    <h2><b>REGISTER ADMIN </b></h2>

<tr>
<td height="36" bgcolor="#FFFFFF"><b>Admin Name:</b></td>
<td height="36" bgcolor="#FFFFFF"><input type="text" name="name" required="required" /></td>
</tr>

<tr>
<td height="36" bgcolor="#FFFFFF"><b>Password:</b></td>
<td height="36" bgcolor="#FFFFFF"><input type="password" name="password" required="required" /></td>
</tr>

<td height="36" bgcolor="#FFFFFF" align="center"><input type="submit" value="REGISTER" /></td>
</form>
</td>
</tr>

 <tr>
            <td colspan='3' align='center' bgcolor='white' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>
