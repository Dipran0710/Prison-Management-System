<html>
<head>
<title> Officer Transfer Form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table width="100%" height="100%" border="0" align="center" bgcolor="grey">
<tr>
<td height="33" align="center" bgcolor="grey">
<font size="5">
<U><h2>Officer Transfer</h2></U>
</font>
</td>
</tr>
<td border="0" style="margin-top:0px;" align="center" id="container" height="5" bgcolor="grey"><tr>
<td>
<form action="processofficer.php" method="post">
<table bgcolor="grey" height="431" border="0" align="center" width="50%">
<td width="34%" bgcolor="grey"><b>Officer Id:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Nid" /></td>
</tr>
<td width="34%" bgcolor="grey"><b>Station Id:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Sid" /></td>
</tr>
<td width="34%" bgcolor="grey"><b>Telephone Number:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Phone" /></td>
</tr>

<tr><td bgcolor="grey"><b>From Prison:</b></td>
        <td> <select name="From">
        <option>MYSURU</option>
		<option>BENGALURU</option>
		<option>HASSAN</option>
		<option>MADIKERI</option>
		<option>MANDYA</option>
		<option>MANGALURU</option></td></tr>
	<tr><td bgcolor="grey"><b>To Prison:</b></td>
        <td> <select name="To">
		<option>MYSURU</option>
		<option>BENGALURU</option>
		<option>HASSAN</option>
		<option>MADIKERI</option>
		<option>MANDYA</option>
		<option>MANGALURU</option></td></tr>
        
<tr>
<td bgcolor="grey"><b>Date of Transfer:</b></td>
<td bgcolor="grey"><input type="text" placeholder="YYYY-MM-DD" name="dot" /></td>

</tr>

  <td height="26" bgcolor="grey" align="center">
  <input type="submit" value="Add" /></td>
 </tr>
</table>
</form>
</td>
<tr>
<td height="33" align="center" bgcolor="sky_blue">
<font size="5">
<a href="adminpanel.php">BACK</a> 
</font>
</td>
</tr>

 <tr>
            <td colspan='3' align='center' bgcolor='grey' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>