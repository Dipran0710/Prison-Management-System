

<head>
  <title> PRISON SERVICES</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
	<table align="center" border="0" bgcolor="black" width="100%" height='100%' cellpadding="9" cellspacing="0" height="525">
          <tr>
            <td colspan="3" height="2"><img src="2.gif" width="100%"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="white" height="1" align="center">
		<font size="4">
        
      
          </font>
            </td>
          </tr>
		 
          <tr>
            <td width='4%' bgcolor='#FFFFFF' valign='top'>


            <td width='71%' valign='top' bgcolor="#FFFFFF">



<h3 align='center'>&nbsp;</h3>
<br/>
<h3 align='center'>WELCOME OFFICER </h3>
<P align=''FACE'><font=54 face='Arial, Helvetica, sans-serif'>This is the home page of an officer.The officer can only view the information of prisoners.</font></p>

			</td>
            <td width='25%' bgcolor='#FFFFFF'  valign='top'>
			
	
<table border='0' align='center'>
<tr>
<td width="252"  bgcolor='black' ">




	<>
		
	<h3><a href='viewprisoners1.php'><b>Prisoners Information</b></a></h3>
		<>
		
	<h3><a href='viewcourt1.php'><b>Court Information</b></a></h3>
		<>
	<h3><a href='viewtransfer1.php'><b>Prisoners Transfer </b></a></h3>
		<>
    <li><a href='index.php'><b>LOG OUT</b></a></li>
	

</td>
</tr>
</table>


			
			</td>
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='white' height='1'>
					 <I><B><strong>
                @SmartKnower_Deep</strong></td></B></I>
          </tr>
	</table>
</body>
</head>
</html>