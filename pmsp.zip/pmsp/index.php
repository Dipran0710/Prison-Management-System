<!DOCTYPE html>
<html>
<head>
	<title></title>

	
	 <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="preconnect" href="https://fonts.gstatic.com">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:wght@600&display=swap" rel="stylesheet">

</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-violet bg-dark">
  <a class="navbar-brand" href="#">*PRISON MANAGEMENT SYSTEM*</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="login2.php">Admin Login<span class="sr-only">(current)</span></a>
	  </li>

	  <li class="nav-item">
        <a class="nav-link" href="register.php">Register Admin <span class="sr-only">(current)</span></a>
	  </li>
    </ul>
    
  </div>
</nav>
<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="Images/c1.jpg" alt="Los Angeles" width="1100" height="500">
    </div>
    <div class="carousel-item">
      <img src="Images/c2.jpg" alt="Chicago" width="1100" height="500">
    </div>
    <div class="carousel-item">
      <img src="Images/c3.jpg" alt="New York" width="1100" height="500">
    </div>
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<section class="my-5">
	<div class="py-5">
		<U><h2 class="text-center">About Us</h2></U>
	</div>
	<div class="container-fluid">
		
	
<div class="row">
	<div class="col-lg-6 cl-md-6 col-12">
	<img src="Images/c4.jpg" class="img-fluid aboutimg">
	</div>
<div class="col-lg-6 cl-md-6 col-12">
	<h2 class="display-4"> Welcome To State Branch Prison Cell </h2>
	<p class="py-4"> According to the enforcement of law all the criminals of Batch B are imprisoned here.</p>
	
	</div>
</div>
</div>
</section>

 <section class="my-5">
	<div class="py-5">
		<U><h2 class="text-center">Project Details</h2><U>
	</div>

  
    <div class="container-fluid">  
		<div class="row">
				<div class="col-lg-3 col-md-4 col-12">
			<div class="card" >
		  <img class="center" src="Images/c12.jpg" alt="Dipran">
		  
		  <div class="card-body">
		   <h3 class="card-title" align="center">Prepared By</h3>
		   <U><p class="card-text" align="center">NAME:-Dipran Bhandari</p> </U>
		    <U> <p class="card-text" align="center">SmartKnower</p></U>
		  </div>

		   </div>
		</div>
    <div class="col-lg-3 col-md-4 col-12">
			<div class="card" >
		  <img class="center"  src="Images/g12.png" alt="Dipran">
		  
		  <div class="card-body">
		   <h3 class="card-title" align="center">Contact Creator</h3>
		   <U><p class="card-text" align="center">Phone-no: 9620301147</p> </U>
		    <U> <a class="card-text" href= "https://github.com/DipranBhandari" aling="center">github:DipranBhandari/dip.run880</a></U>
		  </div>

		   </div>
		</div>
		<div class="col-lg-3 col-md-4 col-12">
			<div class="card" >
		  <img class="center"  src="Images/c31.png" alt="Dipran">
		  
		  <div class="card-body">
		   <h3 class="card-title" align="center">Submitted to</h3>
		   <U><p class="card-text" align="center">Guide & Mentor</p> </U>
		    <U> <p class="card-text" align="center">SmartKnower</p></U>
		  </div>

		   </div>
		</div>
    
    
    <div class="col-lg-3 col-md-4 col-12">
			<div class="card" >
		  <img class="center"  src="Images/c55.png" alt="Dipran">
		  
		  <div class="card-body">
		   <h3 class="card-title" align="center">Contact Institute</h3>
		   <U><p class="card-text" align="center">Phone-no: 9113997071 </p> </U>
		    <U> <a class="card-text" href= "https://www.smartknower.com/aboutus" align="center">Website: support@smartknower.com</a></U>
		  </div>

		   </div>
		</div>

				
		</div>

</div>
		   </div>
		</div>
				
		


	
		   
		</form>
	</div>
</section>

 
   
   <footer>
   	<font size="4"><I> <p class="p-3 bg-dark text-white text-center ">@SmartKnower_Deep</p></I></font>
   </footer>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>


</body>
</html>
