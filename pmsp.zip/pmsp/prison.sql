-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2017 at 01:12 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prison`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `example` ()  BEGIN 
SELECT * FROM police;

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `NEW` (IN `Officer_Id` VARCHAR(20), IN `Station_Id` INT(20), IN `Station_Name` VARCHAR(20), IN `Address` VARCHAR(50), IN `City` VARCHAR(20), IN `Email` VARCHAR(20), IN `Mobile` BIGINT(50), IN `name` VARCHAR(20), IN `password` VARCHAR(20))  BEGIN
         INSERT INTO police
         (
          Officer_Id	,	
          Station_Id           , 
           Station_Name                     , 
           Address                    , 
           City                      , 
           Email                     , 
           Mobile                   ,
           name                   , 
           password      
         )
         
    VALUES 
         ( 
	  Officer_Id,
          Station_Id           , 
           Station_Name                     , 
           Address                    , 
           City                      , 
           Email                     , 
           Mobile                   ,
           name                   , 
           password                     
         ) ;
       END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `Admin_Id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`Admin_Id`, `name`, `password`) VALUES
(1, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `court`
--

CREATE TABLE `court` (
  `National_id` int(12) NOT NULL,
  `File_number` varchar(14) NOT NULL,
  `Dateoftrial` date NOT NULL,
  `Sentence` varchar(14) NOT NULL,
  `Location` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `court`
--

INSERT INTO `court` (`National_id`, `File_number`, `Dateoftrial`, `Sentence`, `Location`) VALUES
(101, '2', '2020-12-28', '15 Above', 'Bengaluru Court');

-- --------------------------------------------------------

--
-- Table structure for table `officer`
--

CREATE TABLE `officer` (
  `Officer_Id` varchar(20) NOT NULL,
  `Station_Id` int(20) NOT NULL,
  `Telephone` bigint(50) NOT NULL,
  `From_Prison` varchar(20) NOT NULL,
  `To_Prison` varchar(20) NOT NULL,
  `Dateoftransfer` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `officer`
--

INSERT INTO `officer` (`Officer_Id`, `Station_Id`, `Telephone`, `From_Prison`, `To_Prison`, `Dateoftransfer`) VALUES
('10', 1, 8878954526, 'MYSURU', 'BENGALURU', '2020-12-28');

-- --------------------------------------------------------

--
-- Table structure for table `police`
--

CREATE TABLE `police` (
  `Officer_Id` varchar(20) NOT NULL DEFAULT '0',
  `Station_Id` int(20) NOT NULL DEFAULT '0',
  `Station_Name` varchar(20) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `City` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Mobile` bigint(50) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `police`
--

INSERT INTO `police` (`Officer_Id`, `Station_Id`, `Station_Name`, `Address`, `City`, `Email`, `Mobile`, `name`, `password`) VALUES
('10', 1, 'Station 1', 'Vijaynagar', 'Mysuru', 'police@police.com', 8878954526, 'Johnny', 'police');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `id` int(10) NOT NULL DEFAULT '0',
  `Full_Name` varchar(23) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(20) NOT NULL,
  `County` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Education` varchar(20) NOT NULL,
  `Marital` varchar(20) NOT NULL,
  `Offence` varchar(90) NOT NULL,
  `Date_in` date NOT NULL,
  `File_num` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `Full_Name`, `DOB`, `Address`, `County`, `Gender`, `Education`, `Marital`, `Offence`, `Date_in`, `File_num`) VALUES
(100, 'John', '1969-09-19', 'Vijaynagar', 'MYSURU', 'Male', 'Diploma', 'Married', 'Robbery', '2020-12-29', '1');

CREATE TABLE `registration_pol` (
  `id` int(10) NOT NULL DEFAULT '0',
  `Full_Name` varchar(23) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(20) NOT NULL,
  `County` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Education` varchar(20) NOT NULL,
  `Marital` varchar(20) NOT NULL,
  `Offence` varchar(90) NOT NULL,
  `Date_in` date NOT NULL,
  `File_num` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Triggers `registration`
--
DELIMITER $$
CREATE TRIGGER `insert` AFTER INSERT ON `registration` FOR EACH ROW BEGIN
INSERT INTO registration_pol
VALUES (new.id,new.Full_Name,new.DOB,new.Address,new.County,new.Gender,new.Education,new.Marital,new.Offence,new.Date_in,new.File_num );
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `registration_bkp`
--

CREATE TABLE `registration_bkp` (
  `id` int(10) NOT NULL DEFAULT '0',
  `Full_Name` varchar(23) NOT NULL,
  `DOB` date NOT NULL,
  `Address` varchar(20) NOT NULL,
  `County` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `Education` varchar(20) NOT NULL,
  `Marital` varchar(20) NOT NULL,
  `Offence` varchar(90) NOT NULL,
  `Date_in` date NOT NULL,
  `File_num` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_bkp`
--

INSERT INTO `registration_bkp` (`id`, `Full_Name`, `DOB`, `Address`, `County`, `Gender`, `Education`, `Marital`, `Offence`, `Date_in`, `File_num`) VALUES
(100, 'John', '1969-09-19', 'Vijaynagar', 'MYSURU', 'Male', 'Diploma', 'Married', 'Robbery', '2020-12-27', '1');

-- --------------------------------------------------------

--
-- Table structure for table `transfer`
--

CREATE TABLE `transfer` (
  `National_id` int(16) NOT NULL,
  `File_num` varchar(16) NOT NULL,
  `From_prison` varchar(17) NOT NULL,
  `To_prison` varchar(18) NOT NULL,
  `Dateoftransfer` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transfer`
--

INSERT INTO `transfer` (`National_id`, `File_num`, `From_prison`, `To_prison`, `Dateoftransfer`) VALUES
(101, '2', 'BENGALURU', 'MADIKERI', '2020-12-29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`Admin_Id`);

--
-- Indexes for table `court`
--
ALTER TABLE `court`
  ADD KEY `National_id` (`National_id`);

--
-- Indexes for table `officer`
--
ALTER TABLE `officer`
  ADD KEY `Officer_Id` (`Officer_Id`);

--
-- Indexes for table `police`
--
ALTER TABLE `police`
  ADD PRIMARY KEY (`Officer_Id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `File_num` (`File_num`);

--
-- Indexes for table `registration_bkp`
--
ALTER TABLE `registration_bkp`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `File_num` (`File_num`);

--
-- Indexes for table `transfer`
--
ALTER TABLE `transfer`
  ADD KEY `National_id` (`National_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `Admin_Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `court`
--
ALTER TABLE `court`
  ADD CONSTRAINT `court_ibfk_1` FOREIGN KEY (`National_id`) REFERENCES `registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `officer`
--
ALTER TABLE `officer`
  ADD CONSTRAINT `officer_ibfk_1` FOREIGN KEY (`Officer_Id`) REFERENCES `police` (`Officer_Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transfer`
--
ALTER TABLE `transfer`
  ADD CONSTRAINT `transfer_ibfk_1` FOREIGN KEY (`National_id`) REFERENCES `registration` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
