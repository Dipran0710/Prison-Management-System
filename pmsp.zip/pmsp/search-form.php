<html>
<head>
  <title>Search</title> 
	<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align="center" border="0" bgcolor="grey" width="100%" height='100%' cellpadding="9" cellspacing="0" height="525">
          <tr>
            <td colspan="3" height="2"><img src="2.gif" width="100%"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="sky_blue" height="1" align="center">
		<font size="4">
        <U><B><a href="adminpanel.php">BACK</a></B></U>
      
          </font>
            </td>
          </tr>
          <tr>
            
            <td width="40%" align="center" bgcolor="grey">
       

<td align="left" bgcolor="grey"><U><h1> Seacrh By ID</h1></U>
<form action="search.php" method="get">
           <label>ID:
         <input type="text" name="keyname" />
       </label>
          <input type="submit" value="Search" />
      </form>
</td>
</tr>
 <tr>
            <td colspan='3' align='center' bgcolor='sky_blue' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>