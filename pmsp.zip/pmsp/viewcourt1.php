<html>
<head>
  <title>Case file Prisoners officer </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='black' width='100%' height='100%' cellpadding='8' cellspacing='0' height='200'>
          <tr>
            <td bgcolor='grey' valign='top'>

<?php


$db_name="prison";
$tbl_name="court";

$conn=mysqli_connect("localhost", "root","") or die(mysqli_error());
mysqli_select_db($conn,"$db_name")or die("cannot connect");

$sel= mysqli_query($conn,"select * from $tbl_name");
echo"<table align='center' width='100%'  bgcolor='black' border='0' cellpadding='3' cellspacing='2' bgcolor='white'>
<caption><U><h1>COURT INFORMATION</h1></U></caption>
<tr bgcolor='sky_blue'>
<th width='3%'>National id</th>
<th width='10%'>Fie Number</th>
<th width='10%'>Date of trial</th>
<th width='15%'>Sentence</th>
<th width='10%'>Location</th>
</tr>";

   while($row=mysqli_fetch_array ($sel))
{
echo "<tr bgcolor='lime'>";

echo  "<td width='3%'>".$row ['National_id']."</td>";
echo  "<td width='7%'>".$row ['File_number']."</td>";
echo  "<td width='10%'>".$row ['Dateoftrial']."</td>";
echo  "<td width='10%'>".$row ['Sentence']. "</td>";
echo  "<td width='10%'>".$row ['Location']."</td>";


echo "</tr>";
}
echo"</table>";

?>

<br/>
			</td>
          </tr>
          <tr>
			<td align="center" height='4%' bgcolor='sky_blue'><font size="5"><a href="officerpanel.php" target="_parent" >BACK <b></b></a></font>
			
			
		
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='sky_blue' height='1'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
	</table>
</body>
</head>
</html>