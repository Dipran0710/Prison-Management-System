<html>
<head>
<title>registration  form</title>
<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table border="0" bgcolor="grey" align="center" width='100%' height='100%'>
<tr bgcolor="grey">
<td align="center" height='7%'>
<font size="4">
<U><h1>Register Prisoner</h1><U>
</font>
</td>
</tr>
<tr>
<td>

<form action="procereg.php" method="post">
<table bgcolor="grey" height="450" border="0" align="center" width="50%">
<tr>
<tr>		
<td width="34%" bgcolor="grey"><b>National Id:</b></td>
<td width="66%" bgcolor="grey"><input type="text" name="Nid" />


</tr>
<tr>
<td bgcolor="grey"><b>Full Name:</b></td>
<td bgcolor="grey"><input type="text" name="Fname" /></td>
</tr>
<tr>
<td bgcolor="grey"><b>Date of Birth:</b></td>
<td bgcolor="grey"><input type="text" placeholder="YYYY-MM-DD" name="dob"/>

</tr>
<tr>
<td bgcolor="grey"><b>Address:</b></td>
<td bgcolor="grey"><input type="text" name="address" /></td>
</tr>
<tr><td bgcolor="grey"><b>County:</b></td>
        <td> <select name="country">
		<option>MYSURU</option>
		<option>BENGALURU</option>
		<option>HASSAN</option>
		<option>MADIKERI</option>
		<option>MANDYA</option>
		<option>MANGALURU</option></tr>
		<tr>
 <td><b>Gender</b></td>
        <td><b><input type="radio" name="Gender" value="Male" checked="checked">
        Male <input type="radio" name="Gender" value="Female"></b>
	   <b>Female</b></td>
	      </tr>
		  
 <tr><td bgcolor="grey"><b>Education Level:</b></td>
        <td> <select name="education">
		<option>Never</option>
		<option>Pre University</option>
		<option>Diploma</option>
        <option>Bachelor Degree</option>
		</td></tr>
		
<tr><td bgcolor="grey"><b>Marital Status:</b></td>
        <td> <select name="status">
		<option>Divorced</option>
		<option>Married</option>
		<option>Single</option></td></tr>
		
<tr><td bgcolor="grey"><b>Offence:</b></td>
        <td> <select name="offence">
        <option>Murder</option>
		<option>Robbery</option>
		<option>Forgery</option>
        <option>Raping</option>
		<option>Other</option></td></tr>
		
		<tr>
<td bgcolor="grey"><b>Date Of Imprisonment:</b></td>
<td bgcolor="grey"><input type="text" placeholder="YYYY-MM-DD" name="di"/>
</tr>

<tr>
<td bgcolor="grey"><b>File Number:</b></td>
<td bgcolor="grey"><input type="text" name="Filenum" /></td>
</tr>

   <td height="26" bgcolor="grey" align="center"><input type="submit" value="SAVE" /></td>
 </tr>
</table>
</form>
</td>
</tr>
<tr bgcolor="skyblue">
<td align="center" height='4%'>
<font size="6">
<a href="adminpanel.php">BACK</a> 
</font>
</td>
</tr>
 <tr>
            <td colspan='3' align='center' bgcolor='grey' height='5'>
					<B><I> <strong>
                @SmartKnower_Deep</strong></td></I></B>
          </tr>
</table>
</body>
</html>