<html>
<head>
   
	<link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align="center" border="0" bgcolor="violet" width="100%" height='100%' cellpadding="9" cellspacing="0" height="525">
          <tr>
            <td colspan="3" height="2"><img src="2.gif" width="100%"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="indigo" height="1" align="center">
		<font size="5">
         <a href="index.php">HOME</a>
      
          </font>
            </td>
          </tr>
          <tr>
            <td width="25%" bgcolor="violet" >&nbsp;&nbsp;<img src="11.jpg" width="550" height="250"  alt=""/></td>
            <td width="50%" align="center" bgcolor="violet">
       
<div class="ex">

<form action="login1.php" method="POST">
<table width="408" height="142" border="0" bgcolor="violet">
	    <h2><b>LOGIN MEMBERS </b></h2>

<tr>
<td height="30" bgcolor="violet"><b>User Name:</b></td>
<td height="30" bgcolor="violet"><input type="text" name="name" required="required"  /></td>
</tr>

<tr>
<td height="30" bgcolor="violet"><b>Password:</b></td>
<td height="30" bgcolor="violet"><input type="password" name="password" required="required" /></td>
</tr>
<tr><td bgcolor="violet"><b>Select User:</b></td>
       <td height="30" bgcolor="violet"> <select name="cmbUser">
		
           
           <option>Admin</option></td></tr>



<td><td height="50" bgcolor="violet" ><input type="submit" value="LOGIN" /></td></td>
</form>
</td>
</tr>
 <tr>
            <td colspan='800' align='right' bgcolor='violet' height='3'>
					<B><I>@SmartKnower_Deep</I></B>
          </tr>
</table>
</body>
</html>